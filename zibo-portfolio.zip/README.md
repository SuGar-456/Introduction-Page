# Zibo He – Portfolio

A minimal Next.js (App Router) site with Tailwind and simple UI components.
Replace the placeholder links in `app/page.tsx` under `projects` and `videos`.

## Quick Start
```bash
npm install
npm run dev
# open http://localhost:3000
```

## Deploy to Vercel
- Push this folder to GitHub, then import the repo in Vercel.
- Framework: Next.js (auto-detected).

